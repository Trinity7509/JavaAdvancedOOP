package callofduty.enteties.agents;

import callofduty.core.MissionControlImpl;
import callofduty.interfaces.Agent;
import callofduty.interfaces.Mission;

import java.util.LinkedHashSet;
import java.util.Set;

public abstract class BaseAgent implements Agent {
    private String id;
    private String name;
    private double rating;
    private MissionControlImpl missionControl;
    private Set<Mission> missionSet;

    public BaseAgent(String id, String name, double rating) {
        this.id = id;
        this.name = name;
        this.rating = rating;
        this.missionControl=new MissionControlImpl();
        this.missionSet=new LinkedHashSet<>();
    }

    @Override
    public void acceptMission(Mission mission) throws NoSuchFieldException, IllegalAccessException {

    }

    @Override
    public void completeMissions() {

    }

    @Override
    public String getId() {
        return this.id;
    }

    @Override
    public String getName() {
        return this.name;
    }

    @Override
    public Double getRating() {
        return this.rating;
    }
}
