package callofduty.enteties.agents;

import callofduty.interfaces.Agent;
import callofduty.interfaces.BountyAgent;

public class MasterAgent extends BaseAgent implements BountyAgent {

    private Double bounty=0.00;



    public MasterAgent(String id, String name, double rating, Double bounty) {
        super(id, name, rating);
        this.bounty = bounty;
    }

    @Override
    public Double getBounty()
    {
        return this.getBounty()+this.bounty;
    }
}
