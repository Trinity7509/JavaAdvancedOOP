package callofduty.enteties.agents;

import callofduty.interfaces.Agent;

public class NoviceAgent extends BaseAgent{

   private Double rating=0.00;



    public NoviceAgent(String id, String name, double rating, Double rating1) {
        super(id, name, rating);
        this.rating = rating1;
    }

    @Override
    public Double getRating()
    {
        return super.getRating()+ this.rating;
    }
}

