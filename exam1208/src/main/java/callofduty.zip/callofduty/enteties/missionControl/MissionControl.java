package callofduty.enteties.missionControl;

import callofduty.enteties.missions.EscortMission;
import callofduty.enteties.missions.HuntMission;
import callofduty.enteties.missions.SurveillanceMission;

import callofduty.interfaces.MissionManager;

import java.util.ArrayList;
import java.util.List;

public class MissionControl implements MissionManager {
    private List<EscortMission> escortMissionList;
    private List<HuntMission> huntMissionList;
    private List<SurveillanceMission> surveillanceMissionList;

    public MissionControl() {
        this.escortMissionList = new ArrayList<>();
        this.huntMissionList = new ArrayList<>();
        this.surveillanceMissionList = new ArrayList<>();
    }


    @Override
    public String agent(List<String> arguments) {
        return null;
    }

    @Override
    public String request(List<String> arguments) {
        return null;
    }

    @Override
    public String complete(List<String> arguments) {
        return null;
    }

    @Override
    public String status(List<String> arguments) {
        return null;
    }

    @Override
    public String over(List<String> arguments) {
        return null;
    }
}

