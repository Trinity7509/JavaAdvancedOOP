package callofduty.enteties.missions;

import callofduty.interfaces.Mission;

public abstract class BaseMission implements Mission {
    private String id;
    private Double rating;
    private Double bounty;

    protected BaseMission(Double rating, Double bounty) {
        this.rating = rating;
        this.bounty = bounty;
    }

    public void setId(String id) {
        String[] input=id.split("");
        int maxLength=8;

        if(input.length>maxLength)

        {
          maxLength=input.length;
        }
        else
        {
            this.id = id;
        }

    }

    public void setRating(Double rating) {
        double minValue=0.00;
        double maxValue=100.00;
        if(rating<minValue)
        {
            rating=minValue;
        }
        else if(rating>maxValue)
        {
            rating=maxValue;
        }
        else {
            this.rating = rating;
        }
    }

    public void setBounty(Double bounty) {
        double minValue=0.00;
        double maxValue=100000.00;
        if(bounty<minValue)
        {
            bounty=minValue;
        }
        else if(bounty>maxValue)
        {
            bounty=maxValue;
        }
        else
        {
            this.bounty = bounty;
        }

    }

    @Override
    public Double getBounty() {
        return this.bounty;
    }

    @Override
    public String getId() {
        return this.id;
    }

    @Override
    public Double getRating() {
        return this.rating;
    }
}
