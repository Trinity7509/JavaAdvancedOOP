package callofduty.enteties.missions;

public class EscortMission extends BaseMission {
    public EscortMission(Double rating, Double bounty) {
        super(rating, bounty);
    }

    @Override
    public Double getRating()
    {
        return super.getRating()*0.75;
    }

    @Override
    public Double getBounty()
    {
        return super.getBounty()*1.25;
    }
}
