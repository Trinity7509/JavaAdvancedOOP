package callofduty.enteties.missions;



public class HuntMission extends BaseMission {
    protected HuntMission(Double rating, Double bounty) {
        super(rating, bounty);
    }
    @Override
    public Double getRating()
    {
        return super.getRating()*0.50;
    }

    @Override
    public Double getBounty()
    {
        return super.getBounty()*2;
    }
}
