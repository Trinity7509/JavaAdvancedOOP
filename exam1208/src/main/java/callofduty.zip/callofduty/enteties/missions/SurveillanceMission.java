package callofduty.enteties.missions;

public class SurveillanceMission extends BaseMission {
    protected SurveillanceMission(Double rating, Double bounty) {
        super(rating, bounty);
    }

    @Override
    public Double getRating()
    {
        return super.getRating()*0.25;
    }

    @Override
    public Double getBounty()
    {
        return super.getBounty()*1.5;
    }

}
