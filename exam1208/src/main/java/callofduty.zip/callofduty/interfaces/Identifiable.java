package callofduty.interfaces;

public interface Identifiable {
    String getId();
}
