package callofduty.interfaces;

public interface InputReader {
    String readLine();
}
