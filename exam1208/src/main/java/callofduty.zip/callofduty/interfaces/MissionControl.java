package callofduty.interfaces;

public interface MissionControl {
    Mission generateMission(String missionId, Double missionRating, Double missionBounty);
}
