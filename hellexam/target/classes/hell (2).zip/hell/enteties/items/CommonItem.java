package hell.enteties.items;

public class CommonItem extends BaseItem {
    public CommonItem(String name, int strengthBonus,
                         int agilityBonus, int intelligenceBonus,
                         int hitPointsBonus, int damageBonus) {
        super(name, strengthBonus, agilityBonus, intelligenceBonus, hitPointsBonus, damageBonus);
    }
}
