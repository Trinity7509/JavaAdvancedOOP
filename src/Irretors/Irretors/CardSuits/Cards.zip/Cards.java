package Irretors.Irretors.CardSuits;

public enum  Cards {


    CLUBS, DIAMONDS, HEARTS, SPADES;
}
