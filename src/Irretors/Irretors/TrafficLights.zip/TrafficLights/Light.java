package Irretors.Irretors.TrafficLights;

public enum Light {
    RED, GREEN ,YELLOW;
}
